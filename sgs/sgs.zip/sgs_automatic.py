from sgs_automatic_Aux import *


def main():
    args = parser()
    all_flow(args)


if __name__ == "__main__":
    main()

